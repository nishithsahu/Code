package dp;

public class ZeroOneKnapsack {

	public static void main(String[] args) {
		
		
	}
}
